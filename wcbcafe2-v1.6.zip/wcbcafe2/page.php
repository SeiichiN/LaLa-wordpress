<?php get_header(); ?>
<div class="notice">page.php</div>

<!-- <header class="post-page-header">
     <h1 class="page-title"><?php // single_cat_title() ?></h1>
     </header> -->
<div class="wrapper content-title">
  <h2 class="page-title"><?php the_title() ?></h2>
</div>
</div><!-- /.big-bg -->


<!-- <div class="wrapper"> -->
<?php
if (have_posts()):
  while (have_posts()):
    the_post();
    get_template_part('content');
  endwhile;
endif;
?>
<!-- </div> -->

<?php get_footer(); ?>

<!-- 修正時刻: Mon 2023/10/30 06:33:36 -->
