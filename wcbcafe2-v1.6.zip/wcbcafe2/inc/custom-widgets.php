<?php

/**
 * sidebar.php にお店の紹介文を入れるウィジェット
 */
class ShowShopExplain extends WP_Widget {
  function __construct() {
    parent::__construct (
      'wcbcafe_widget_id002',
      'お店の紹介文表示ウィジェット',
      array ('description' => 'お店の紹介文を表示')
    );
  }

  /**
   * $args -- functions.php の中で設定した値を格納した配列
   * $instance -- このクラスの form で入力した値を格納した配列
   */
  public function widget($args, $instance) {
    echo $args['before_title'];
    echo esc_html($instance['title']);
    echo $args['after_title'];
    echo $args['before_widget'];
    echo esc_html($instance['explain']);
    echo $args['after_widget'];
  }

  function form ($instance) {
  ?>
    <p>
      <label for="<?php echo $this->get_field_name('title'); ?>">タイトル：</label>
      <input type="text" class="widefat"
             id="<?php echo $this->get_field_id('title'); ?>"
             name="<?php echo $this->get_field_name('title'); ?>"
             value="<?php echo esc_attr($instance['title']); ?>"/>
    </p>
    <p>
      <label for="<?php echo $this->get_field_id('explain'); ?>">内容：</label>
      <textarea class="widefat"
                id="<?php echo $this->get_field_name('explain'); ?>"
                name="<?php echo esc_html($instance['explain']); ?>"></textarea>
                
    </p>
  <?php
  }

  function update($new_instance, $old_instance) {
    if ($old_instance === null) {
      $instance = array();
    } else {
      $instance = $old_instance;
    }
    $instance['title'] = $new_instance['title'];
    $instance['explain'] = $new_instance['explain'];
    return $instance;
  }  
}
add_action('widgets_init', function() {
  register_widget('ShowShopExplain');
});



/**
 * NEWSカテゴリーのサブカテゴリー一覧を表示するウィジェット
 */
class ShowNewsCategory extends WP_Widget {
  function __construct() {
    parent::__construct (
      'wcbcafe_widget_id003',
      'NEWSのサブカテゴリー表示ウィジェット',
      array ('description' => 'NEWSカテゴリーのサブカテゴリー一覧を表示')
    );
  }

  /**
   * $args -- functins.php の category_widget_init で指定した
   *          before_widget などの値が格納された array配列
   * $instance -- このクラスの form そして update で指定した値が
   *          格納された配列
   * ここでの echo は sidebarの指定されたエリアに出力される
   */
  public function widget($args, $instance) {
    $cat_id = (int) $instance['cat_id'];
    echo $args['before_title'];
    echo esc_html($instance['title']);
    echo $args['after_title'];
    $categories = get_categories( array(
      'child_of' => $cat_id,
    ));
    echo $args['before_widget'];
    foreach( $categories as $category) {
      echo '<li><a href="' . get_category_link($category->cat_ID) . '">' .
           $category->name . '</a></li>';
    }
    echo $args['after_widget'];
  }

  /**
   * 外観 -- ウィジェットの設定画面に表示されるフォーム
   *
   * $instance['title'] に $this->get_field_name('title')がセットされる。
   * $instance['cat_id'] に $this->get_field_name('cat_id')がセットされる。
   */
  function form ($instance) {
?>
  <?php // 「カテゴリー」という見出しを入力できるようにする。 ?>
  <p>
    <label for="<?php echo $this->get_field_name('title'); ?>">タイトル：</label>
    <input type="text" class="widefat"
           id="<?php echo $this->get_field_id('title'); ?>"
           name="<?php echo $this->get_field_name('title'); ?>"
           value="<?php echo esc_attr($instance['title']); ?>"/>
  </p>
  <p>
    <label for="<?php echo $this->get_field_id('cat_id'); ?>">カテゴリ：</label>
    <select class="widefat"
            id="<?php echo $this->get_field_id('cat_id'); ?>"
            name="<?php echo $this->get_field_name('cat_id'); ?>">
      <?php
      $categories = get_categories();
      foreach ($categories as $category) {
        if ($category->parent === 0) {
          $instance['cat_id'] = $category->cat_ID;
      ?>
        <option value="<?php echo esc_attr($instance['cat_id']); ?>">
          <?php echo $category->cat_ID, $category->cat_name; ?>
        </option>
      <?php
      }
      }
      ?>
    </select>
  </p>
<?php
}

/**
 * $old_instance の中が空みないなので、以下のように変更。
 */
function update ($new_instance, $old_instance) {
  if ($old_instance == null) {
    $instance = array();
  } else {
    $instance = $old_instance;
  }
  $instance['title'] = $new_instance['title'];
  $instance['cat_id'] = $new_instance['cat_id'];
  return $instance;
}
}
add_action('widgets_init', function() {
  register_widget('ShowNewsCategory');
});





/**
 * 各ページの全画面用の画像を設定するウィジェット
 * 開発途中
 */
class SetBigImageWidget extends WP_Widget {
  function __construct() {
    parent::__construct(
      'wcbcafe_widget_id003',
      '全画面画像ウィジェット',
      array('description' => '全画面画像を設定する')
    );
  }

  /**
   * $args -- functions.phpの中で設定した値を格納した配列
   * $instance -- このクラスの form で入力した値を格納した配列
   */
  public function widget($args, $instance) {
    echo esc_html($instance['image']);
  }

  function form ($instance) {
?>
  <label for="<?php echo $this->get_field_id('image') ?>">画像</label>
  <input type="file"
         id="<?php echo $this->get_field_id('image') ?>"
         name="<?php echo $this->get_field_name('image') ?>" />
<?php
}

function update($new_instance, $old_instance) {
  if ($old_instance == null) {
    $instance = array();
  } else {
    $instance = $old_instance;
  }
  return $instance;
}  
}


/* 修正時刻: Sat 2023/11/04 01:16:53 */
