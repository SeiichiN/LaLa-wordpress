<?php get_header(); ?>
  <div class="notice">archive.php</div>

  <div class="wrapper content-title">
    <h1 class="page-title"><?php single_cat_title() ?></h1>
  </div>
</div><!-- /.big-bg -->

  <div class="wrapper grid">
  <?php
  if (have_posts()):
    while (have_posts()):
      the_post();
      get_template_part('content-archive');
    endwhile;
  endif;
  ?>
</div>


<?php get_footer(); ?>

<!-- 修正時刻: Fri 2023/11/03 10:27:05 -->
