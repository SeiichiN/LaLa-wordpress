<?php
// 投稿記事で、カテゴリーの"feature"にチェックを入れたものがここに入る。
$box = new WP_Query(array(
  'posts_per_page' => -1,
  'category_name' => 'feature',
  'orderby' => 'menu_order',
  'order' => 'asc'
));
?>
<ul class="news-nav">
  <?php if ($box->have_posts()) : ?>
    <?php while ($box->have_posts()) : ?>
      <?php $box->the_post(); ?>
          
      <li class="news-nav-item" ?>
        <div>
          <a href="<?php the_permalink(); ?>">
            <?php the_post_thumbnail(
              'big_thumbnail',
              array('alt' => the_title_attribute('echo=0'),
                    'title' => the_title_attribute('echo=0'))); ?>
          </a>
        </div>
        <header class="entry-header">
          <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
        </header>
        <p class="entry-content">
          <?php the_excerpt(); ?>
        </p>

      </li>
    <?php endwhile; ?>
  <?php endif; ?>
</ul>
<?php wp_reset_postdata(); ?>

<?php /* 修正時刻: Wed 2023/11/01 06:11:151 */
      
