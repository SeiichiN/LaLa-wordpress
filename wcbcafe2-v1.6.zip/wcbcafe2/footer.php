<footer>
  <div class="wrapper footer-widget-area">
      <?php if (is_active_sidebar('footer-area-1')): ?>
        <?php dynamic_sidebar('footer-area-1'); ?>
      <?php endif; ?>
      <?php if (is_active_sidebar('footer-area-2')): ?>
        <?php dynamic_sidebar('footer-area-2'); ?>
      <?php endif; ?>
      <?php if (is_active_sidebar('footer-area-3')): ?>
        <?php dynamic_sidebar('footer-area-3'); ?>
      <?php endif; ?>
  </div><!-- /.wrapper footer-widget-area -->
  <div class="wrapper">
    <p><small>&copy; 2019 Manabox</small></p>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>

<!-- 修正時刻: Tue 2023/10/31 05:54:35 -->
