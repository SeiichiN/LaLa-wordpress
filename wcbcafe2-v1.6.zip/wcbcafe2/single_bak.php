<?php get_header(); ?>
<div class="notice">single.php</div>
</div><!-- /.big-bg -->

<header class="post-page-header">
  <h1 class="page-title"><?php single_cat_title() ?></h1>
</header>

<?php
if (have_posts()):
while (have_posts()):
the_post();
get_template_part('content-single');
endwhile;
endif;
?>

<?php get_footer(); ?>

<!-- 修正時刻: Wed 2023/10/18 09:00:37 -->
