<!DOCTYPE html>
<html <?php language_attributes(); ?>>
  <head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <title><?php bloginfo('name'); ?></title>
    <meta name="description" content="<?php bloginfo('description'); ?>">
    <link rel="icon" type="image/png" href="<?php echo get_template_directory_uri() ?>/images/favicon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSS -->
    <!-- <link rel="stylesheet" href="https://unpkg.com/ress/dist/ress.min.css"> -->
    <link href="https://fonts.googleapis.com/css?family=Philosopher" rel="stylesheet">
    <link href="<?php echo get_stylesheet_uri(); ?>" rel="stylesheet">
    <?php wp_head(); ?>
  </head>

  <body>
    <?php
    $p_name = esc_attr($post->post_name);
    // echo '$p_name:', $p_name;
    if ($p_name === 'home' || $p_name === 'menu' || $p_name === 'contact') {
      ;
    } else if (preg_match("/menu./", $p_name)) {
      $p_name = 'menu';
    } else {
      $p_name = 'news';
    }
    ?>
    <div id="<?php echo $p_name ?>" <?php post_class('big-bg') ?>>
        <?php
        /* 大きな画像 */
        $sidebar = 'header-image-' . $p_name;
        if (is_active_sidebar($sidebar)) {
          dynamic_sidebar($sidebar);
        }
        ?>
      <!-- <div class="notice2"><?php // echo $sidebar ?></div> -->
      <header class="page-header wrapper">
        <h1>
          <a href="<?php echo esc_url(home_url('/')); ?>">
            <img class="logo" src="<?php echo get_template_directory_uri() ?>/images/logo.svg" alt="WCBカフェ ホーム">
          </a>
        </h1>
        <?php
        wp_nav_menu( array(
          'container' => 'nav',
          'menu_class' => 'main-nav',
          'theme_location' => 'place_global',
        ));
        ?>
      </header>
      
      <!-- 修正時刻: Sat 2023/11/04 10:22:07 -->
