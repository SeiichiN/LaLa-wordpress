<?php get_header(); ?>
  <div class="notice">front-page.php</div>
  
  <div class="home-content wrapper">
    <h2 class="page-title">We'll Make Your Day</h2>
    <p>おしゃれなカフェで癒やされてみませんか？無添加の食材で体の中からリフレッシュ。</p>
    <a class="button" href="menu.html">メニューを見る</a>
  </div><!-- /.home-content -->
  </div><!-- /#home -->

  <section id="new-article">
    <div class="wrapper">
      <header class="section-header">
        <h2>新着情報</h2>
      </header>
      <?php get_template_part('feature'); ?>
    </div><!-- /.wrapper -->
  </section>

  <section id="sub-navigation">
    <h2>コンテンツ</h2>
    <div class="wrapper">
      <div class="sub-nav">
        <div class="nav-item">
          <?php if (is_active_sidebar('toppage-link-area-1')): ?>
            <?php dynamic_sidebar('toppage-link-area-1'); ?>
          <?php endif; ?>
        </div>
        <div class="nav-item">
          <?php if (is_active_sidebar('toppage-link-area-2')): ?>
            <?php dynamic_sidebar('toppage-link-area-2'); ?>
          <?php endif; ?>
        </div>
        <div class="nav-item">
          <?php if (is_active_sidebar('toppage-link-area-3')): ?>
            <?php dynamic_sidebar('toppage-link-area-3'); ?>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </section>


<?php get_footer(); ?>
<!-- 修正時刻: Wed 2023/11/01 18:27:05 -->
