<article>
  <header class="post-info">
    <h2 class="page-title"><?php the_title(); ?></h2>
    <p class="post-date">
      <?php the_time('d/m') ?>
      <span><?php the_time('Y') ?></span>
      <p class="post-cat">カテゴリー：<?php echo get_the_category()[0]->name ?></p>
    </p>      
  </header>
  <?php the_content(); ?>
</article>



<!-- 修正時刻: Sun 2023/10/29 06:56:17 -->
