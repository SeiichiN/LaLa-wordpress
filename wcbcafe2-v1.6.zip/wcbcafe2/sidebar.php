<aside>
  <?php if (is_active_sidebar('category-list-area')): ?>
    <?php dynamic_sidebar('category-list-area'); ?>
  <?php endif; ?>
</aside>

<!-- 修正時刻: Sun 2023/10/29 06:56:17 -->
