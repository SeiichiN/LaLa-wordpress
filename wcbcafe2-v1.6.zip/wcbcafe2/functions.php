<?php
/**
 * WCB Cafe functions and definition
 */

// require get_template_directory() . '/inc/custom-widgets.php';


// カスタムメニュー
register_nav_menus (
  array (
    'place_global' => 'グローバル',
    'place_footer' => 'フッター',
  )
);

// アイキャッチ画像
add_theme_support('post-thumbnails');
set_post_thumbnail_size(90, 90, true);
add_image_size('small_thumbnail', 61, 61, true);
add_image_size('large_thumbnail', 300, 300, false);


function header_image_widgets_init() {
  register_sidebar( array(
    'name' => 'Home Header Image',
    'id'   => 'header-image-home',
    'description' => 'ホームヘッダーイメージウィジェット',
    'before_widget' => '<li id="home-header-widget" class="header-widget %2$s">',
    'after_widget' => '</li>',
  ));

  register_sidebar( array(
    'name' => 'Menu Header Image',
    'id'   => 'header-image-menu',
    'description' => 'メニューヘッダーイメージウィジェット',
    'before_widget' => '<li id="menu-header-widget" class="header-widget %2$s">',
    'after_widget' => '</li>',
  ));

  register_sidebar( array(
    'name' => 'Contact Header Image',
    'id'   => 'header-image-contact',
    'description' => 'コンタクトヘッダーイメージウィジェット',
    'before_widget' => '<li id="contact-header-widget" class="header-widget %2$s">',
    'after_widget' => '</li>',
  ));

  register_sidebar( array(
    'name' => 'News Header Image',
    'id'   => 'header-image-news',
    'description' => 'ニュースヘッダーイメージウィジェット',
    'before_widget' => '<li id="news-header-widget" class="header-widget %2$s">',
    'after_widget' => '</li>',
  ));
}
add_action('widgets_init', 'header_image_widgets_init');

function category_widget_init() {
  register_sidebar( array(
    'name' => __('Category List Area'),
    'id'   => 'category-list-area',
    'description' => 'sidebar.php(single.php)にカテゴリーを入れるウィジェット',
    'before_widget' => '<ul class="sub-menu">',
    'after_widget' => '</ul>',
    'before_title' => '<h3 class="sub-title">',
    'after_title' => '</h3>',
  ));
}
add_action('widgets_init', 'category_widget_init');

/**
 * Implements the Custom Widgets
 * 自作のウィジェットを組み込む
 */
require get_template_directory() . '/inc/custom-widgets.php';

/**
 * NEWS固定ページのタイトルの下の説明文
 */
function menu_description_init() {
  register_sidebar( array(
    'name' => 'Menu Desctiption Area',
    'id' => 'menu-description-area',
    'description' => 'MENUページにメッセージを入れるウィジェット',
  ));
}
add_action('widgets_init', 'menu_description_init');

function contact_input_init() {
  register_sidebar( array(
    'name' => __('Contact Input Area'),
    'id' => 'contact-input-area',
    'description' => 'CONTACTページにフォームを入れるウィジェット',
    'before_widget' => '',
    'after_widget' => '',
  ));
}
add_action('widgets_init', 'contact_input_init');

function footerarea_widgets_init() {
  register_sidebar( array(
    'name' => __('Footer Area 1'),
    'id' => 'footer-area-1',
    'description' => 'フッターウィジェット-1',
    'before_widget' => '<div class="footer-widget-content">',
    'after_widget' => '</div>',
    'before_title' => '<h2><span class="moji">',
    'after_title' => '</span></h2>',
  ));
  
  register_sidebar( array(
    'name' => __('Footer Area 2'),
    'id' => 'footer-area-2',
    'description' => 'フッターウィジェット-2',
    'before_widget' => '<div class="footer-widget-content">',
    'after_widget' => '</div>',
    'before_title' => '<h2><span class="moji">',
    'after_title' => '</span></h2>',
  ));

  register_sidebar( array(
    'name' => __('Footer Area 3'),
    'id' => 'footer-area-3',
    'description' => 'フッターウィジェット-3',
    'before_widget' => '<div class="footer-widget-content">',
    'after_widget' => '</div>',
    'before_title' => '<h2><span class="moji">',
    'after_title' => '</span></h2>',
  ));
}
add_action('widgets_init', 'footerarea_widgets_init');

function toppage_link_area_init() {
  register_sidebar( array(
    'name' => __('Toppage Link Area 1'),
    'id' => 'toppage-link-area-1',
    'description' => 'トップページ ウィジェット 1',
    'before_widget' => '',
    'after_widget' => '',
    'before_title' => '',
    'after_title' => '',
  ));

  register_sidebar( array(
    'name' => __('Toppage Link Area 2'),
    'id' => 'toppage-link-area-2',
    'description' => 'トップページ ウィジェット 2',
    'before_widget' => '',
    'after_widget' => '',
    'before_title' => '',
    'after_title' => '',
  ));

  register_sidebar( array(
    'name' => __('Toppage Link Area 3'),
    'id' => 'toppage-link-area-3',
    'description' => 'トップページ ウィジェット 3',
    'before_widget' => '',
    'after_widget' => '',
    'before_title' => '',
    'after_title' => '',
  ));
}
add_action('widgets_init', 'toppage_link_area_init');


/* 修正時刻: Wed 2023/11/01 18:27:05 */
