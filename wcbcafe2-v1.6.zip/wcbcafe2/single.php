<?php get_header(); ?>
<div class="notice">single.php</div>

<div class="wrapper content-title">
  <?php
  $catName = get_the_category()[0]->name;
  if ($catName === 'feature') {
    $catName = get_the_category()[1]->name;
  }
  ?>
  <h1 class="page-title"><?php echo $catName; ?></h1>
</div>

</div><!-- /.big-bg -->

<div class="news-contents wrapper">
  <?php
  if (have_posts()):
    while (have_posts()):
      the_post();
      get_template_part('content-single');
    endwhile;
  endif;
  ?>

  <?php get_sidebar(); ?>
</div><!-- /.news-contents wrapper -->  

<?php get_footer(); ?>

<!-- 修正時刻: Fri 2023/11/03 12:08:37 -->
