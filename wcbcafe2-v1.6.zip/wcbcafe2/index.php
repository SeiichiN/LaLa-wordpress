<?php echo 'index.php';

