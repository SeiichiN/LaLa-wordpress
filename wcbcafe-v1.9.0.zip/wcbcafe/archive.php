<?php get_header(); ?>

<?php // echo 'archive.php'; ?>

<header class="post-page-header">
  <h1 class="page-title"><?php single_cat_title(); ?></h1>
</header>
</div>
<div class="wrapper grid">
  <?php
  if (have_posts()) :
    while (have_posts()) :
      the_post ();
      get_template_part('content-archive');
    endwhile;
  endif;
  ?>
</div>
<?php get_footer(); ?>

<?php // 修正時刻: Sat Aug 28 16:55:04 2021 ?>
