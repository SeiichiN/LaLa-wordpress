<?php get_header(); ?>

<div class="home-content wrapper">
  <h2 class="page-title">We'll Make Your Day</h2>
  <p>おしゃれなカフェで癒されてみませんか？無添加の素材で体の中からリフレッシュ。</p>
  <a href="<?php echo home_url('/menu'); ?>" class="button">メニューを見る</a>
</div><!-- /.home-content -->
</div><!-- #home .big-bg -->

<?php wp_footer(); ?>
</body>
</html>

<?php // 修正時刻: Tue Aug 24 14:54:18 2021 ?>
