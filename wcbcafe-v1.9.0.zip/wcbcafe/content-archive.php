<!-- <div class="wrapper"> -->
  <article>
    <a href="<?php the_permalink(); ?>">
      <?php the_post_thumbnail('large_thumbnail',
                               array ('alt' => the_title_attribute('echo=0'),
                                      'titie' => the_title_attribute('echo=0'))) ?></a>
    <header class="entry-header">
      <time pubdate="pubdate" datetime="<?php the_time('Y-m-d'); ?>"
            class="entry-date"><?php the_time(get_option('date_format')); ?></time>
      <h2 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
    </header>
    <section class="entry-content"><?php the_excerpt(); ?></section>
  </article>
<!-- </div> -->

<?php // 修正時刻: Thu Aug 26 17:27:42 2021 ?>
