<article>
  <header  class="post-info">
    <h2 class="post-title"><?php the_title(); ?></h2>
    <time class="post-date" datetime="<?php the_time('Y-m-d'); ?>">
      <?php the_time('m/d'); ?>
      <span><?php the_time('Y'); ?></span></time>
    <p class="post-cat">カテゴリー：<?php echo get_the_category()[1]->cat_name; ?></p>
      <?php // 検証用
      // $categories = get_the_category();
      // echo '<pre>'; print_r($categories); echo '</pre>';
      ?>
  </header>
  <?php   the_content (); ?>
</article>

<?php // 修正時刻: Tue 2022/08/16 11:53:241 ?>
