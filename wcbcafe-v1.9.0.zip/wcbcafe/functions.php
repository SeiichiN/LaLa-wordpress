<?php
/**
 * functions.php
 */ 

// カスタムメニュー
register_nav_menus (
  array (
    'place_global' => 'グローバル',
    'place_footer' => 'フッター',
  )
);

// アイキャッチ画像を利用できるようにする
add_theme_support('post-thumbnails');

// アイキャッチ画像のサイズ
set_post_thumbnail_size(90, 90, true);
// サイドバー用
add_image_size('small_thumbnail', 61, 61, true);
// アーカイブ用
add_image_size('large_thumbnail', 400, 400, false);

// カスタム背景
$args = array(
  'default-color' => '',
  'default-image' => '',
  'default-repeat' => '',
  'default-position-x'=> '',
  'default-attachment' => '',
  'wp-head-callback' => '_custom_background_cb',
  'admin-head-callback' => '',
  'admin=preview-callback' => ''
);
add_theme_support( 'custom-background', $args );


/***************************************************
 * Implements the Custom Widgets
 * 自作のウィジェットを組み込む
 ***************************************************/
require get_template_directory() . '/inc/custom-widgets.php';

require get_template_directory() . '/inc/footer-title-widgets.php';


/**
 * sidebar.php(single.php) に カテゴリーを入れるウィジェット
 * 外観 -> ウィジェット
 */
/**
 * NEWSの個別ページのサイド: NEWSカテゴリーの一覧を表示
 */
function category_widgets_init() {
  register_sidebar( array(
    'name' => __('Category List Area'),
    'id'   => 'category-list-area',
    'description' => 'sidebar.php(single.php) に カテゴリーを入れるウィジェット',
    'before_widget' => '<ul class="sub-menu">',
    'after_widget' => '</ul>',
    'before_title' => '<h3 class="sub-title">',
    'after_title' => '</h3>',
  ));
}
add_action('widgets_init', 'category_widgets_init');

/**
 * NEWSの個別ページのサイド: お店についてを表示する
 */
function shop_explain_init() {
  register_sidebar( array(
    'name' => __('Shop Explain Area'),
    'id' => 'shop-explain-area',
    'description' => 'sidebar.php(single.php) に お店の紹介文を入れるウィジェット',
    'before_widget' => '<p>',
    'after_widget' => '</p>',
    'before_title' => '<h3 class="sub-title">',
    'after_title' => '</h3>',
  ));
}
add_action('widgets_init', 'shop_explain_init');

/**
 * MENU固定ページのタイトルの下の説明文
 */
function menu_description_init() {
  register_sidebar( array(
    'name' => __('Menu Description Area'),
    'id' => 'menu-description-area',
    'description' => 'MENUページにメッセージを入れるウィジェット',
    'before_widget' => '',
    'after_widget' => '',
    'before_title' => '',
    'after_title' => '',
  ));
}
add_action('widgets_init', 'menu_description_init');

/**
 * CONTACT固定ページのフォームを設置する
 */
function contact_input_init() {
  register_sidebar( array(
    'name' => __('Contact Input Area'),
    'id' => 'contact-input-area',
    'description' => 'CONTACTページにフォームを入れるウィジェット',
    'before_widget' => '<div>',
    'after_widget' => '</div>',
    'before_title' => '',
    'after_title' => '',
  ));
}
add_action('widgets_init', 'contact_input_init');



/**
 * フッターエリアにウィジェットを入れる
 */
function footerarea1_widgets_init() {
  register_sidebar( array(
    'name'          => __('Footer Area 1'),
    'id'            => 'footer-area-1',
    'description'   => 'フッターウィジェット1',
    'before_widget' => '<div class="footer-widget-content">',
    'after_widget'  => '</div>',
    'before_title'  => '<h2><span class="moji">',
    'after_title'   => '</span></h2>',
  ));
}
add_action( 'widgets_init', 'footerarea1_widgets_init' );

function footerarea2_widgets_init() {
  register_sidebar( array(
    'name'          => __('Footer Area 2'),
    'id'            => 'footer-area-2',
    'description'   => 'フッターウィジェット1',
    'before_widget' => '<div class="footer-widget-content">',
    'after_widget'  => '</div>',
    'before_title'  => '<h2><span class="moji">',
    'after_title'   => '</span></h2>',
  ));
}
add_action( 'widgets_init', 'footerarea2_widgets_init' );

function footerarea3_widgets_init() {
  register_sidebar( array(
    'name'          => __('Footer Area 3'),
    'id'            => 'footer-area-3',
    'description'   => 'フッターウィジェット1',
    'before_widget' => '<div class="footer-widget-content">',
    'after_widget'  => '</div>',
    'before_title'  => '<h2><span class="moji">',
    'after_title'   => '</span></h2>',
  ));
}
add_action( 'widgets_init', 'footerarea3_widgets_init' );



// 修正時刻: Mon 2022/10/17 18:40:481

