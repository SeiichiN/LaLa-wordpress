<?php get_header(); ?>

<?php // echo 'page.php'; ?>

  <?php
  if (have_posts()) :
    while (have_posts()) :
      the_post ();
      get_template_part('content');
    endwhile;
  endif;
  ?>
  
<?php get_footer(); ?>

<?php // 修正時刻: Sun Aug 29 20:57:44 2021 ?>
