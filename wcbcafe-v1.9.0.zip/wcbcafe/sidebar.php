<aside>
<?php if (is_active_sidebar('category-list-area')) : ?>
   <?php dynamic_sidebar('category-list-area'); ?>
<?php endif; ?>

<?php if (is_active_sidebar('shop-explain-area')) : ?>
  <?php dynamic_sidebar('shop-explain-area'); ?>
<?php endif; ?>
</aside>

<?php // 修正時刻: Fri Aug 27 21:18:19 2021
