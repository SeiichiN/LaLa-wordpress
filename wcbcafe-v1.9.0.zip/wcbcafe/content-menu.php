<?php // echo 'content.php'; ?>

<div class="menu-content wrapper">
  <h2 class="page-title"><?php the_title(); ?></h2>
  <?php if (is_active_sidebar('menu-description-area')) : ?>
    <?php dynamic_sidebar('menu-description-area'); ?>
  <?php endif; ?>
</div>
</div><!-- .big-bg End -->

<div class="wrapper content-main">
  <?php the_content (); ?>
</div>

<?php // 修正時刻: Mon Aug 30 21:30:25 2021 ?>
