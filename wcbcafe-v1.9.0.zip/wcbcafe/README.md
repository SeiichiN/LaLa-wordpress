# wcbcafe
Study of making theme of WordPress

## version 1.8.3
フッターエリアにウィジェット機能を組み込んだ

## version 1.9.0


<!-- 修正時刻: Mon 2022/11/07 07:19:04 -->
