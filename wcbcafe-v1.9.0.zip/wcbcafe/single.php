<?php get_header(); ?>

<?php // echo 'single.php'; ?>

<div class="news-wrapper wrapper">
  <h1 class="page-title"><?php echo get_the_category()[0]->name; ?></h1>
</div>
<!--
<pre><?php // print_r(get_the_category()); ?></pre>
-->

<div class="news-contents wrapper">
  <?php
  if (have_posts()) :
    while (have_posts()) :
      the_post ();
      get_template_part('content-single');
    endwhile;
  endif;
  ?>

  <?php get_sidebar(); ?>
</div>

<?php get_footer(); ?>

<?php // 修正時刻: Fri Aug 27 20:23:28 2021 ?>
