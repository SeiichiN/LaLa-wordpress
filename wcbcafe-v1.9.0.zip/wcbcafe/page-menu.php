<?php get_header(); ?>

<?php echo 'page-menu.php'; ?>

  <?php
  if (have_posts()) :
    while (have_posts()) :
      the_post ();
      get_template_part('content-menu');
    endwhile;
  endif;
  ?>
  
<?php get_footer(); ?>

<?php // 修正時刻: Mon Aug 30 21:23:26 2021 ?>
