<div class="wrapper">
  <h2 class="page-title"><?php the_title(); ?></h2>
  <?php   the_content (); ?>
</div>

<?php // 修正時刻: Thu Aug 26 13:20:44 2021 ?>
