<?php
/**
 * Header file for the WCB Cafe Wordpress theme.
 *
 * @package WordPress
 * @subpackage WCB Cafe
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>

  <head>
	<meta charset="<?php bloginfo('charset'); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?php bloginfo('name'); ?></title>
	<meta name="description" content="<?php bloginfo('description'); ?>">
	<link rel="icon" type="image/png"
          href="<?php echo get_template_directory_uri(); ?>/images/favicon.png">

	<link rel="stylesheet" href="https://unpkg.com/ress/dist/ress.min.css">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Philosopher&display=swap" rel="stylesheet">
	<link href="<?php echo get_stylesheet_uri(); ?>" rel="stylesheet">
    <?php wp_head(); ?>
  </head>

  <body <?php body_class() ?>>
    <div id="<?php echo esc_attr($post->post_name); ?>"<?php post_class('big-bg'); ?>>
	  <!-- <div id="home" class="big-bg"> -->
	  <header class="page-header wrapper">
		<h1>
		  <a href="<?php echo home_url('/'); ?>">
			<img src="<?php echo get_template_directory_uri(); ?>/images/logo.svg" alt="WCBカフェホーム" class="logo">
		  </a>
		</h1>
        <?php wp_nav_menu( array(
          'container' => 'nav',
          'menu_class' => 'main-nav',
          'theme_location' => 'place_global',
        ));
        ?>
	  </header>

<?php // 修正時刻: Tue 2022/10/18 06:08:441 ?>
