<footer>
  <div class="wrapper footer-widget-area">
    <div class="footer-widget">
      <?php if (is_active_sidebar('footer-area-1')) : ?>
        <?php dynamic_sidebar('footer-area-1'); ?>
      <?php endif; ?>
    </div>
    <div class="footer-widget">
      <?php if (is_active_sidebar('footer-area-2')) : ?>
        <?php dynamic_sidebar('footer-area-2'); ?>
      <?php endif; ?>
    </div>
    <div class="footer-widget">
      <?php if (is_active_sidebar('footer-area-3')) : ?>
        <?php dynamic_sidebar('footer-area-3'); ?>
      <?php endif; ?>
    </div>
  </div><!-- .row -->
  <div class="wrapper">
      <p><small>&copy; 2019 Manabox</small></p>
      <?php /* wp_nav_menu( array(
        'container'      => 'nav',
        'menu_class'     => 'sub-nav',
        'theme_location' => 'place_footer',
      ));
      */ ?>
    </div>
  </footer>

  <?php wp_footer(); ?>
</body>

</html>


<?php // 修正時刻: Tue 2022/08/23 13:06:201

